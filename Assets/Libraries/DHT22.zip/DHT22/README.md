# DHT22
 Arduino library for interface with DHT22 sensor 
 Without use of pointers.

[datasheet](extras/DHT22-datasheet.pdf)

sample module :
![module](extras/dht22.webp)

https://fr.aliexpress.com/wholesale?SearchText=DHT22
